// app.ts
import { WechatMiniprogram } from "wechat-miniprogram"
import { App } from "wechat-miniprogram"

interface IAppOption {
  globalData: {
    userInfo?: WechatMiniprogram.UserInfo
    isApiMode: boolean
    userId?: string
  }
  userInfoReadyCallback?: WechatMiniprogram.GetUserInfoSuccessCallback
}

App<IAppOption>({
  globalData: {
    isApiMode: false, // 默认使用模拟模式
  },

  onLaunch() {
    // 展示本地存储能力
    const logs = WechatMiniprogram.getStorageSync("logs") || []
    logs.unshift(Date.now())
    WechatMiniprogram.setStorageSync("logs", logs)

    // 登录
    WechatMiniprogram.login({
      success: (res) => {
        console.log("登录成功", res.code)
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      },
    })

    // 检查API模式设置
    const apiMode = WechatMiniprogram.getStorageSync("apiMode")
    if (apiMode !== undefined) {
      this.globalData.isApiMode = apiMode
    }
  },

  // 切换API模式
  toggleApiMode() {
    this.globalData.isApiMode = !this.globalData.isApiMode
    WechatMiniprogram.setStorageSync("apiMode", this.globalData.isApiMode)

    WechatMiniprogram.showToast({
      title: this.globalData.isApiMode ? "已切换到API模式" : "已切换到模拟模式",
      icon: "success",
    })
  },
})
