"use client"

import  from "../pages/profile/profile"

export default function SyntheticV0PageForDeployment() {
  return < />
}